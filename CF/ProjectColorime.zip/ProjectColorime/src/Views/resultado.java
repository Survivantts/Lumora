/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;

import javax.swing.ImageIcon;

/**
 *
 * @author Aluno
 */
public class resultado extends javax.swing.JFrame {

    /**
     * Creates new form resultado
     */
    public resultado(String tomPele, String corCabelo, String corOlho) {
        initComponents();
        this.setResizable(false);
        this.setIconImage(new javax.swing.ImageIcon(getClass().getResource("/Views/imagens/survivants.png")).getImage());
        jlogo1.setVisible(false);
        if (tomPele.equals("Preto") && corCabelo.equals("Loiro") && corOlho.equals("Verde")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta01.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Loiro") && corOlho.equals("Verde")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta02.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Branco") && corCabelo.equals("Loiro") && corOlho.equals("Azul")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta03.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Preto") && corCabelo.equals("Ruivo") && corOlho.equals("Verde")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta04.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Ruivo") && corOlho.equals("Azul")) {
           ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta05.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Preto") && corCabelo.equals("Loiro") && corOlho.equals("Azul")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta06.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Branco") && corCabelo.equals("Loiro") && corOlho.equals("Verde")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta07.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Preto") && corCabelo.equals("Castanho") && corOlho.equals("Verde")) {
           ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta08.png"));
           jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Castanho") && corOlho.equals("Azul")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta09.png"));
            jpaleta.setIcon(imagem);

        }
        else if (tomPele.equals("Preto") && corCabelo.equals("Preto") && corOlho.equals("Castanho")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta10.png"));
            jpaleta.setIcon(imagem);

        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Preto") && corOlho.equals("Castanho")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta11.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Preto") && corCabelo.equals("Castanho") && corOlho.equals("Castanho")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta12.png"));
            jpaleta.setIcon(imagem);       }
        else if (tomPele.equals("Preto") && corCabelo.equals("Ruivo") && corOlho.equals("Castanho")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta13.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Preto") && corOlho.equals("Azul")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta14.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Preto") && corOlho.equals("Verde")) {
           ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta15.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Branco") && corCabelo.equals("Ruivo") && corOlho.equals("Azul")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta16.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Branco") && corCabelo.equals("Preto") && corOlho.equals("Castanho")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta17.png"));
            jpaleta.setIcon(imagem);
        }
        else if (tomPele.equals("Pardo") && corCabelo.equals("Castanho") && corOlho.equals("Verde")) {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta18.png"));
            jpaleta.setIcon(imagem); 
        }
        else {
            ImageIcon imagem = new ImageIcon(getClass().getResource("/Views/imagens/paleta00.png"));
            jpaleta.setIcon(imagem);
            jlogo2.setVisible(false);
            jlogo1.setVisible(true);
            
        }
    }

    private resultado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlogo1 = new javax.swing.JLabel();
        jpaleta = new javax.swing.JLabel();
        jlogo2 = new javax.swing.JLabel();
        jrefazer = new javax.swing.JButton();
        jsair = new javax.swing.JButton();
        jfundos = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlogo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Views/imagens/logoapp.png"))); // NOI18N
        getContentPane().add(jlogo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 50, -1, 140));
        getContentPane().add(jpaleta, new org.netbeans.lib.awtextra.AbsoluteConstraints(-290, 47, 770, 440));

        jlogo2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Views/imagens/entrega.png"))); // NOI18N
        getContentPane().add(jlogo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 210));

        jrefazer.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jrefazer.setText("Refazer");
        jrefazer.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jrefazer.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jrefazer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrefazerActionPerformed(evt);
            }
        });
        getContentPane().add(jrefazer, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 390, 120, 30));

        jsair.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jsair.setText("Sair");
        jsair.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jsair.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jsair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jsairActionPerformed(evt);
            }
        });
        getContentPane().add(jsair, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 390, 120, 30));

        jfundos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Views/imagens/fundo.jpg"))); // NOI18N
        getContentPane().add(jfundos, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jrefazerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrefazerActionPerformed
        AppPrincipal nova = new AppPrincipal();
        nova.setVisible(true);
        dispose();

    }//GEN-LAST:event_jrefazerActionPerformed

    private void jsairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jsairActionPerformed
        divisao abrir = new divisao();
        abrir.setVisible(true);
        dispose();
    }//GEN-LAST:event_jsairActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(resultado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(resultado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(resultado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(resultado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jfundos;
    private javax.swing.JLabel jlogo1;
    private javax.swing.JLabel jlogo2;
    private javax.swing.JLabel jpaleta;
    private javax.swing.JButton jrefazer;
    private javax.swing.JButton jsair;
    // End of variables declaration//GEN-END:variables
}
